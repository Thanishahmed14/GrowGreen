package com.example.growgreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.growgreen.service.NetworkBroadcast;

import java.util.ArrayList;

public class PlantDiseaseActivity extends AppCompatActivity {

    ImageView homeButton, settingsButton, diseaseButton;
    RecyclerView mRecyclerview;
    ArrayList<Diseases> diseasesList=new ArrayList<>();

    BroadcastReceiver broadcastReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_disease);

        broadcastReceiver = new NetworkBroadcast();
        registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

        homeButton = findViewById(R.id.homeButton);
        settingsButton = findViewById(R.id.settingsButton);
        diseaseButton = findViewById(R.id.diseaseButton);
        diseasesList=Diseases.getDiseases("disease.json",this);
        mRecyclerview=findViewById(R.id.recyclerView);
        DiseaseAdapter adapter=new DiseaseAdapter(diseasesList, this);
        mRecyclerview.setAdapter(adapter);
        //mRecyclerview.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));
        mRecyclerview.setLayoutManager(new LinearLayoutManager(this));


        diseaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlantDiseaseActivity.this, PlantDiseaseActivity.class);
                startActivity(intent);
                finish();
            }
        });


        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlantDiseaseActivity.this, SettingsActivity.class);
                startActivity(intent);
                finish();
            }
        });


        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PlantDiseaseActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }

        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
}