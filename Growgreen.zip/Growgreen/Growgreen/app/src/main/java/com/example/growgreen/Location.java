package com.example.growgreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.growgreen.service.NetworkBroadcast;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class Location extends AppCompatActivity {

    private int REQUEST_LOCATION_CODE = 101;

    TextView txtLongitude;

    TextView txtLatitude;

    Button btnWhere;
    ImageView close;

    BroadcastReceiver broadcastReceiver;

    FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        broadcastReceiver = new NetworkBroadcast();
        registerReceiver(broadcastReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

        //get references to textViews and the button
        txtLongitude = findViewById(R.id.txtLongitude);
        txtLatitude = findViewById(R.id.txtLatitude);
        btnWhere = findViewById(R.id.btnWhere);
        close = findViewById(R.id.closeView);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Location.this, SettingsActivity.class);
                startActivity(intent);
                finish();
            }
        });
        fusedLocationProviderClient =
                LocationServices.getFusedLocationProviderClient(this);

        btnWhere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Calling the where() methood
                //this method is implemented seperately
                where();
            }
        });
    }//end of Oncreate()

    private void where() {
        //Creating a new locationManager object to access location service of the
        LocationManager locationManager =
                (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if
        (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            noGPSAlert();
        } else if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            noPermissionsAlert();
        } else {
            getLocation();
        }
    }

    private void noGPSAlert() {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Enable Location");
        b.setMessage("Please enable location settings to use app");
        b.setPositiveButton("Location Settings", new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new
                                Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                });
        b.setNegativeButton("Cancel", null);
        b.show();
        //Toast.makeText(getApplicationContext(),"no GPS",Toast.LENGTH_SHORT).show();
    }

    private void noPermissionsAlert() {
        ActivityCompat.requestPermissions(this, new
                String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION_CODE);
        //Toast.makeText(getApplicationContext(),"no Permissions ",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull
    String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions,
                grantResults);
        if (requestCode == REQUEST_LOCATION_CODE && grantResults != null &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getLocation();
        }
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this,
                new OnSuccessListener<android.location.Location>() {
                    @Override
                    public void onSuccess(android.location.Location location) {
                        if (location == null) {
                            Toast.makeText(getApplicationContext(), "problems",
                                    Toast.LENGTH_SHORT).show();
                        } else {

                            txtLongitude.setText(Double.toString(location.getLongitude()));

                            txtLatitude.setText(Double.toString(location.getLatitude()));
                        }
                    }
                });
        //Toast.makeText(getApplicationContext(),"get Location",Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
}