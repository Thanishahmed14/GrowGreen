package com.example.growgreen;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DiseaseAdapter extends RecyclerView.Adapter<DiseaseAdapter.DiseaseViewHolder> {
    ArrayList<Diseases> diseases;
    Context mContext;

    public DiseaseAdapter(ArrayList<Diseases> diseases, Context mContext) {
        this.diseases = diseases;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public DiseaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new DiseaseViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_diseases,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull DiseaseViewHolder holder, int position) {
        Diseases theDisease=diseases.get(position);
        holder.txtDisease.setText(diseases.get(position).diseaseName);
        holder.txtTitle.setText(diseases.get(position).title);
        holder.txtSynopsis.setText(diseases.get(position).synopsis);
        holder.txtType.setText(diseases.get(position).type);


        Resources res=holder.itemView.getContext().getResources();
        int id=res.getIdentifier("@drawable/"+theDisease.cover,"drawable", "com.example.growgreen");
        holder.imgCover.setImageResource(id);

    }

    @Override
    public int getItemCount() {
        return diseases.size();
    }


    public class DiseaseViewHolder extends RecyclerView.ViewHolder {

        TextView txtDisease, txtType, txtSynopsis, txtTitle;
        ImageView imgCover;



        public DiseaseViewHolder(@NonNull View itemView) {
            super(itemView);

            txtSynopsis =itemView.findViewById(R.id.txtSynopsis);
            txtDisease =itemView.findViewById(R.id.txtDisease);
            txtType =itemView.findViewById(R.id.txtType);
            txtTitle =itemView.findViewById(R.id.txtTitle);
            imgCover =itemView.findViewById(R.id.imgCover);
        }
    }
}


