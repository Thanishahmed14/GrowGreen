package com.example.growgreen;

import static java.nio.charset.StandardCharsets.UTF_8;

import android.content.BroadcastReceiver;
import android.content.Context;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

    public class Diseases {
        String diseaseName;
        String title;
        String type;
        String synopsis;
        String cover;

    public Diseases(String diseaseName, String title, String type, String synopsis, String cover) {
        this.diseaseName = diseaseName;
        this.title = title;
        this.type = type;
        this.synopsis = synopsis;
        this.cover = cover;
    }


    @NonNull
    static ArrayList<Diseases> getDiseases(String fileName, Context context){
        //create arraylist of Disease objects
        ArrayList<Diseases> diseaseList=new ArrayList<>();
        try {
            InputStream inputStream = context.getAssets().open(fileName);

            byte[] buffer = new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();

            //JSONObject json=new JSONObject(new String(buffer), StandardCharsets.UTF_8));
            JSONObject json = new JSONObject(new String(buffer, UTF_8));
            JSONArray disease = json.getJSONArray("disease");

            for (int i = 0; i < disease.length(); i++) {
                diseaseList.add(new Diseases(
                                disease.getJSONObject(i).getString("Author"),
                                disease.getJSONObject(i).getString("Title"),
                                disease.getJSONObject(i).getString("ISBN"),
                                disease.getJSONObject(i).getString("Synopsis"),
                                disease.getJSONObject(i).getString("Cover")
                        )

                );

            }

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return diseaseList;
    }

}
